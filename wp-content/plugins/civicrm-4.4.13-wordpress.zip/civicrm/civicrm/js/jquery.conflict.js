var cj = jQuery.noConflict(); $ = cj;
